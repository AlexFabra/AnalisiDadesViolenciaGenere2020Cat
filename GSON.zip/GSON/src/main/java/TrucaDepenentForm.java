import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
//A la classe 'TrucaDepenentForm' hi son els atributs i métodes per relacionar qui truca amb els estudis de la víctima: 
public class TrucaDepenentForm {
    //declarem un HashMap amb clau String i Valor Integer:
    private static Map<String, Integer> nTrucadesFormacio = new HashMap<String, Integer>();
    //declarem un TreeMap on guardarem, organitzades, les dades del HashMap:
    private static TreeMap<String, Integer> ntfOrdenadas = new TreeMap<>();
    
    public void afegeix(String trucant, String formacio) {
        //si 'trucant' té un valor String vuit:
        if(trucant.equals("")){
            //ho cambiem per anònim:
            trucant = "Anònim";
        } 
        if(formacio.equals("")){
            //ho cambiem per anònim:
            formacio = "No consta";
        } 

        //creem un vector String amb els paràmetres del métode:
        String key=("qui truca: "+trucant+". Formació de la víctima: "+formacio);
        //si el map conté el vector:
        if(this.nTrucadesFormacio.containsKey(key))
        {
            //declarem un int i ho inicialitzem amb el valor de la clau més 1. 
            int valor = this.nTrucadesFormacio.get(key) + 1;
            //i actualitzem el valor de la clau:
            this.nTrucadesFormacio.put(key, valor);
        }
        //si no hi és la clau:
        else{
            //la posem en el map amb valor 1, ja que hem trobat el primer exemple:
            this.nTrucadesFormacio.put(key, 1);
        }
    }
    /*
    Sobrescribim la funció toString per a que ens retorni el valor en String de la classe.
     */
    @Override
    public String toString() {
        // si no ordenem aquestes dades, la llegibilitat del output disminuirà.
        // amb putAll, copiem totes les dades del hashMap en el TreeMap, que les ordena automàticament:
        ntfOrdenadas.putAll(nTrucadesFormacio);

        String result = "";
        result += "Relació entre qui truca i la formació de la pressumpta víctima:\n";
        //recorrem el TreeMap i guardem les dades a result:
        for (Map.Entry<String, Integer> entry : ntfOrdenadas.entrySet()){
            result += entry.getKey() + " = " + entry.getValue() + "\n"; 
        }

        return result;
    }
}