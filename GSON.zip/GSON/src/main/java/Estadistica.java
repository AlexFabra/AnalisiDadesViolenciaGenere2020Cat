import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.swing.*;
import java.beans.DefaultPersistenceDelegate;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.time.format.SignStyle;
import java.util.ArrayList;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class Estadistica {

    public static void main(String[] args) {

        //clase gson:
        Gson gson = new Gson();
        int totalDenuncies = 0;

        EstadisticaEdat eEdat = new EstadisticaEdat();
        EstadisticaRAgressor rAgressor = new EstadisticaRAgressor();
        EstadisticaAnysRelacio aRelacio = new EstadisticaAnysRelacio();
        AnysRelacioParella aRelacioPar = new AnysRelacioParella();
        ViolenciaDomestica vDom = new ViolenciaDomestica();
        TipusViolencia tViolencia = new TipusViolencia();
        Denunciant trucant = new Denunciant();
        TrucaDepenentForm tdf = new TrucaDepenentForm();

        /*
        Llegim el fitxer de de dades passant-li el path a Reader.
        la llibreria Reader crea un buffer per llegir el fitxer:
        */

        try (Reader reader = new FileReader("c:\\projecte\\GSON\\violencia_masclista.json")) {

            /*
            Creem un ArrayList, anomenat list, on guardarem les dades del fitxer violencia-masclista.json
            en els objectes de la classe Denuncia
            */

            ArrayList<Denuncia> list = gson.fromJson(reader, new TypeToken<ArrayList<Denuncia>>() {}.getType());

            // Ja podem saber el nombre total de denúncies mirant la mida del Array de Denuncies
            totalDenuncies = list.size();

            // Ja tenim un arrayList de objectes denuncies que podeu recorrer i treballar

            for(int i = 0; i < list.size(); i++)
            {
                //volem saber la edat de la persona denunciant:
                eEdat.afegeix(list.get(i).getEdat());
                //volem saber la relació de la persona denunciant amb el presunt agressor:
                rAgressor.afegeix(list.get(i).getRelacioAgressor());
                //volem saber el temps de relació de la persona denunciant amb el presunt agressor:
                aRelacio.afegeix(list.get(i).getTempsRelacio());
                //volem saber quant de temps porten amb la parella, si aquesta és el presunt agressor:
                aRelacioPar.afegeix(list.get(i).getTempsRelacio(),list.get(i).getRelacioAgressor());
                vDom.afegeix(list.get(i).getConviuAgressor());
                tViolencia.classificaTipus(list.get(i).getViolenciaFisica(), list.get(i).getViolenciaEconomica(),list.get(i).getViolenciaSexual(),list.get(i).getViolenciaPsicologica());
                trucant.afegeix(list.get(i).getQuiTruca());
                tdf.afegeix(list.get(i).getQuiTruca(),list.get(i).getFormacio());
            
            }

        /* Si hi ha cap error a la lectura de el fitxer: */
        } catch (IOException e) {
            //printStackTrace() serveix per veure l'error:
            e.printStackTrace();
        }

        /*
        Creem si no existeix el fitxer de sortida i escribim el contingut.
         */

        Writer writer = null;

        try {
            writer = new BufferedWriter(new OutputStreamWriter(
                    new FileOutputStream(new File("c:\\projecte\\GSON\\Sortida.txt")), "utf-8"));

            //guardem les dades al fitxer de sortida

            writer.write("El número total de denúncies el 2020 va ser de " + String.valueOf(totalDenuncies) + "\n\n");

            writer.write(String.valueOf(eEdat) + "\n");
            writer.write(String.valueOf(rAgressor) + "\n");
            writer.write(String.valueOf(aRelacio) + "\n");
            writer.write(String.valueOf(aRelacioPar) + "\n");
            writer.write(String.valueOf(vDom) + "\n");
            writer.write("Denuncies formulades per: \n");
            writer.write(String.valueOf(trucant) + "\n");
            writer.write(String.valueOf(tdf) + "\n");

            //imprimim els atributs de l'objecte tViolencia:
            writer.write("El número de denúncies per maltracte: \n");
            writer.write("físic ="+ tViolencia.getViolenciaFisica()+ "\n");
            writer.write("sexual ="+ tViolencia.getViolenciaSexual()+ "\n");
            writer.write("econòmic ="+ tViolencia.getViolenciaEconomica()+ "\n");
            writer.write("psicològic ="+ tViolencia.getViolenciaPsicologica()+ "\n");

            writer.write("\nPercentatges de denúncies: \n");
            writer.write("Per violència sexual = "+TipusViolencia.percentatgeTipusViolencia(totalDenuncies,tViolencia.getViolenciaSexual())+ "\n");
            writer.write("Per violència física = "+TipusViolencia.percentatgeTipusViolencia(totalDenuncies,tViolencia.getViolenciaFisica())+ "\n");
            writer.write("Per violència psicológica = "+TipusViolencia.percentatgeTipusViolencia(totalDenuncies,tViolencia.getViolenciaPsicologica())+ "\n");
            writer.write("Per violència Econòmica = "+TipusViolencia.percentatgeTipusViolencia(totalDenuncies,tViolencia.getViolenciaEconomica())+ "\n");

        } catch (IOException ex) {
            // Report
        } finally {
            try {writer.close();} catch (Exception ex) {/*ignore*/}
        }

    }

}
