import java.util.HashMap;
import java.util.Map;
public class EstadisticaRAgressor {

    //Les edats les guardarem en una tupla del nom de l'edat i el número de casos d'aquesta edat.
    private Map<String, Integer> rAgressor = new HashMap<String, Integer>();

    /*
    Funció on afegim una nova edat a la tupla si no existia o incrementem una aparició altrament.
     */

    public void afegeix(String rAgressor) {

        if(rAgressor.equals("") || rAgressor.equals("No consta")) rAgressor = "Sense especificar";

        if(this.rAgressor.containsKey(rAgressor))
        {
            int valor = this.rAgressor.get(rAgressor) + 1;
            this.rAgressor.put(rAgressor, valor);
        }
        else{
            this.rAgressor.put(rAgressor, 1);
        }
    }

    /*
    Sobrescribim la funció toString per a que ens retorni el valor en String de la classe.
     */
    @Override
    public String toString() {

        String result = "";
        result += "Relació amb l'agressor:\n";
        for (Map.Entry<String, Integer> entry : this.rAgressor.entrySet()) {
            result += entry.getKey() + " = " + entry.getValue() + "\n";
        }

        return result;
    }
}

