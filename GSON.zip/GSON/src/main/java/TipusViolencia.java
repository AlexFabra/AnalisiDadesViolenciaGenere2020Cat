import jdk.swing.interop.SwingInterOpUtils;

public class TipusViolencia {

    //variables on es guardaràn les dades:
    private int violenciaFisica;
    private int violenciaEconomica;
    private int violenciaSexual;
    private int violenciaPsicologica;

    //constructor sense paràmetres:
    public TipusViolencia(){
        this.violenciaFisica=0;
        this.violenciaEconomica=0;
        this.violenciaSexual=0;
        this.violenciaPsicologica=0;
    }

    /** Aquesta funció actualitza(suma 1) la variable int de la classe que correspongui a la variable String que
     * entri pel paràmetre amb valor 'Sí'.
     * @param vFisica String que tindrà el valor 'Sí' o 'No' segons si a la denúncia consta que s'ha patit.
     * aquest tipus de violència.
     * @param vEconomica "
     * @param vSexual "
     * @param vPsicologica "
     */
    public void classificaTipus(String vFisica, String vEconomica, String vSexual, String vPsicologica){
        if(vFisica.equals("Sí")){
            setViolenciaFisica(getViolenciaFisica()+1);
        }
        if (vEconomica.equals("Sí")){
            setViolenciaEconomica(getViolenciaEconomica()+1);
        }
        if (vSexual.equals("Sí")){
            setViolenciaSexual(getViolenciaSexual()+1);
        }
        if (vPsicologica.equals("Sí")) {
            setViolenciaPsicologica(getViolenciaPsicologica() + 1);
        }

    }

    /** La funció percentatgeTipusViolencia, donat el total de denúncies i el numero
     *  del tipus de violencia del qual es es vol saber el percentatge, retorna aquest.
     * @param total es el número total de denúncies.
     * @param nTipusViolencia és el número de denuncies d'un tipus concret.
     * (funciona correctament si el total de les dades s'ha processat)
     * @return el percentatge de denuncies d'aquest tipus.
     */
    public static int percentatgeTipusViolencia(int total, int nTipusViolencia){
        
        int aux = (total/100);
        int percentatge = nTipusViolencia / aux;
        
        return percentatge;
    }


    public int getViolenciaPsicologica() {
        return violenciaPsicologica;
    }

    public void setViolenciaPsicologica(int violenciaPsicologica) {
        this.violenciaPsicologica = violenciaPsicologica;
    }

    public int getViolenciaEconomica() {
        return violenciaEconomica;
    }

    public void setViolenciaEconomica(int violenciaEconomica) {
        this.violenciaEconomica = violenciaEconomica;
    }

    public int getViolenciaSexual() {
        return violenciaSexual;
    }

    public void setViolenciaSexual(int violenciaSexual) {
        this.violenciaSexual = violenciaSexual;
    }

    public int getViolenciaFisica() {
        return violenciaFisica;
    }

    public void setViolenciaFisica(int violenciaFisica) {
        this.violenciaFisica = violenciaFisica;
    }
}
