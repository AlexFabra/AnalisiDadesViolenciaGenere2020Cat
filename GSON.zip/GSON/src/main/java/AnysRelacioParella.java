import java.util.HashMap;
import java.util.Map;

//la classe AnysRelacioParella relaciona el fet que l'agressor sigui una parella amb els anys que portin de relació:
public class AnysRelacioParella {

    // Amb un map, classificarem el numero de denúncies segons els anys de relació entre la persona
    // denunciant i el el suposat agressor:

    private Map<String, Integer> aRelacioP = new HashMap<String, Integer>();

    /*
    Funció on afegim una nova edat a la tupla si no existia o incrementem una aparició altrament.
     */

    /** Passats dos String (un ha de ser amb el paràmetre que representa els anys de relació entre denunciant i agressor
     *  i l'altre el tipus de relació amb l'agressor) la funció 'afegeix' classifica dins del map aRelacioP els anys de
     *  relació de la parella.
     * @param aRelacio és l'String el valor del qual representa els anys de relació
     * @param rAgressor és l'String el valor del qual representa el tipus de relació entre la persona denunciant i el
     * supossat agressor.
     * @param aRelacioP és el map on es guarda el temps que porta la denunciant amb la parella.
     */
    public void afegeix(String aRelacio, String rAgressor) {
        //si el presumpte agressor és la parella, compleix el condicional:
        if(rAgressor.equals("Parella")) {
            //si 'aRelacio' no té valor o té valor 'no consta', ho passem a 'Sense especificar'.
            if (aRelacio.equals("") || aRelacio.equals("No consta")) aRelacio = "Sense especificar";
            //si aRelacioP ja té guardat el valor 'aRelacio' que li estem passant,
            if (this.aRelacioP.containsKey(aRelacio)) {
                //declarem un valor on guardem el valor actual de 'aRelacio' + 1:
                int valor = this.aRelacioP.get(aRelacio) + 1;
                //i ho guardem al map:
                this.aRelacioP.put(aRelacio, valor);
            } else {
                //creem una nova clau, iniciant-la amb el valor 1, ja que hem trobat el primer cas:
                this.aRelacioP.put(aRelacio, 1);
            }
        }
    }

    /*
    Sobrescribim la funció toString per a que ens retorni el valor en String de la classe.
     */
    @Override
    public String toString() {

        String result = "";
        result += "Anys de relació amb la parella:\n";
        for (Map.Entry<String, Integer> entry : this.aRelacioP.entrySet()) {
            result += entry.getKey() + " = " + entry.getValue() + "\n";
        }

        return result;
    }
}



