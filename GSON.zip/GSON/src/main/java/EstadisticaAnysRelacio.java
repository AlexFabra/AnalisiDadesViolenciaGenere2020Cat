import java.util.HashMap;
import java.util.Map;
//la classe EstadisticaAnysRelacio ajuda a classificar el temps de relació entre les víctimes i els denunciants: 
public class EstadisticaAnysRelacio {

    // Amb un map, classificarem el numero de denúncies segons els anys de relació entre la persona
    // denunciant i el el suposat agressor:
    private Map<String, Integer> aRelacio = new HashMap<String, Integer>();


    /** Passat un String (ha de ser amb el paràmetre que representa els anys de relació entre denunciant i agressor)
     *  la funció 'afegeix' classifica dins del map aRelacio els anys de relació.
     * @param aRelacio és l'objecte que guarda els anys de relació (String) i les vegades que es repeteix (int)
     */
    public void afegeix(String aRelacio) {

        if(aRelacio.equals("") || aRelacio.equals("No consta")) aRelacio = "Sense especificar";

        if(this.aRelacio.containsKey(aRelacio))
        {
            int valor = this.aRelacio.get(aRelacio) + 1;
            this.aRelacio.put(aRelacio, valor);
        }
        else{
            this.aRelacio.put(aRelacio, 1);
        }
    }

    /*
    Sobrescribim la funció toString per a que ens retorni el valor en String de la classe.
     */
    @Override
    public String toString() {

        String result = "";
        result += "Anys de relació amb l'agressor:\n";
        for (Map.Entry<String, Integer> entry : this.aRelacio.entrySet()) {
            result += entry.getKey() + " = " + entry.getValue() + "\n";
        }

        return result;
    }
}


