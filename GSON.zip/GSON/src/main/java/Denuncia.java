public class Denuncia {
    //ací hi don tots els paràmetres de l'arxiu json
    private String data;
    private int any;
    private String comarca;
    private String provincia;
    private String sexe;
    private String edat;
    private String estatCivil;
    private String quiTruca;
    private String situacioFamiliar;
    private String descendencia;
    private String nombreFills;
    private String nacionalitat;
    private String formacio;
    private String situacioLaboral;
    private String detallSituacioLaboral;
    private String usPrevi;
    private String violenciaFisica;
    private String violenciaPsicologica;
    private String violenciaSexual;
    private String violenciaEconomica;
    private String conviuAgressor;
    private String relacioAgressor;
    private String tempsRelacio;
    private String nacionalitatAgressor;

    //getters and setters


    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public int getAny() {
        return any;
    }

    public void setAny(int any) {
        this.any = any;
    }

    public String getComarca() {
        return comarca;
    }

    public void setComarca(String comarca) {
        this.comarca = comarca;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public String getEdat() {
        return edat;
    }

    public void setEdat(String edat) {
        this.edat = edat;
    }

    public String getEstatCivil() {
        return estatCivil;
    }

    public void setEstatCivil(String estatCivil) {
        this.estatCivil = estatCivil;
    }

    public String getQuiTruca() {
        return quiTruca;
    }

    public void setQuiTruca(String quiTruca) {
        this.quiTruca = quiTruca;
    }

    public String getSituacioFamiliar() {
        return situacioFamiliar;
    }

    public void setSituacioFamiliar(String situacioFamiliar) {
        this.situacioFamiliar = situacioFamiliar;
    }

    public String getDescendencia() {
        return descendencia;
    }

    public void setDescendencia(String descendencia) {
        this.descendencia = descendencia;
    }

    public String getNombreFills() {
        return nombreFills;
    }

    public void setNombreFills(String nombreFills) {
        this.nombreFills = nombreFills;
    }

    public String getNacionalitat() {
        return nacionalitat;
    }

    public void setNacionalitat(String nacionalitat) {
        this.nacionalitat = nacionalitat;
    }

    public String getFormacio() {
        return formacio;
    }

    public void setFormacio(String formacio) {
        this.formacio = formacio;
    }

    public String getSituacioLaboral() {
        return situacioLaboral;
    }

    public void setSituacioLaboral(String situacioLaboral) {
        this.situacioLaboral = situacioLaboral;
    }

    public String getDetallSituacioLaboral() {
        return detallSituacioLaboral;
    }

    public void setDetallSituacioLaboral(String detallSituacioLaboral) {
        this.detallSituacioLaboral = detallSituacioLaboral;
    }

    public String getUsPrevi() {
        return usPrevi;
    }

    public void setUsPrevi(String usPrevi) {
        this.usPrevi = usPrevi;
    }

    public String getViolenciaFisica() {
        return violenciaFisica;
    }

    public void setViolenciaFisica(String violenciaFisica) {
        this.violenciaFisica = violenciaFisica;
    }

    public String getViolenciaPsicologica() {
        return violenciaPsicologica;
    }

    public void setViolenciaPsicologica(String violenciaPsicologica) {
        this.violenciaPsicologica = violenciaPsicologica;
    }

    public String getViolenciaSexual() {
        return violenciaSexual;
    }

    public void setViolenciaSexual(String violenciaSexual) {
        this.violenciaSexual = violenciaSexual;
    }

    public String getViolenciaEconomica() {
        return violenciaEconomica;
    }

    public void setViolenciaEconomica(String violenciaEconomica) {
        this.violenciaEconomica = violenciaEconomica;
    }

    public String getConviuAgressor() {
        return conviuAgressor;
    }

    public void setConviuAgressor(String conviuAgressor) {
        this.conviuAgressor = conviuAgressor;
    }

    public String getRelacioAgressor() {
        return relacioAgressor;
    }

    public void setRelacioAgressor(String relacioAgressor) {
        this.relacioAgressor = relacioAgressor;
    }

    public String getTempsRelacio() {
        return tempsRelacio;
    }

    public void setTempsRelacio(String tempsRelacio) {
        this.tempsRelacio = tempsRelacio;
    }

    public String getNacionalitatAgressor() {
        return nacionalitatAgressor;
    }

    public void setNacionalitatAgressor(String nacionalitatAgressor) {
        this.nacionalitatAgressor = nacionalitatAgressor;
    }

    @Override
    public String toString() {
        return "Denuncia{" +
                "data='" + data + '\'' +
                ", any=" + any +
                ", comarca='" + comarca + '\'' +
                ", provincia='" + provincia + '\'' +
                ", sexe='" + sexe + '\'' +
                ", edat='" + edat + '\'' +
                ", estatCivil='" + estatCivil + '\'' +
                ", quiTruca='" + quiTruca + '\'' +
                ", situacioFamiliar='" + situacioFamiliar + '\'' +
                ", descendencia='" + descendencia + '\'' +
                ", nombreFills='" + nombreFills + '\'' +
                ", nacionalitat='" + nacionalitat + '\'' +
                ", formacio='" + formacio + '\'' +
                ", situacioLaboral='" + situacioLaboral + '\'' +
                ", detallSituacioLaboral='" + detallSituacioLaboral + '\'' +
                ", usPrevi='" + usPrevi + '\'' +
                ", violenciaFisica='" + violenciaFisica + '\'' +
                ", violenciaPsicologica='" + violenciaPsicologica + '\'' +
                ", violenciaSexual='" + violenciaSexual + '\'' +
                ", violenciaEconomica='" + violenciaEconomica + '\'' +
                ", conviuAgressor='" + conviuAgressor + '\'' +
                ", relacioAgressor='" + relacioAgressor + '\'' +
                ", tempsRelacio='" + tempsRelacio + '\'' +
                ", nacionalitatAgressor='" + nacionalitatAgressor + '\'' +
                '}';
    }

}
