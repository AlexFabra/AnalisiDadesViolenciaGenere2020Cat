import java.util.HashMap;
import java.util.Map;

public class EstadisticaEdat {

    //Les edats les guardarem en una tupla del nom de l'edat i el número de casos d'aquesta edat.
    private Map<String, Integer> edades = new HashMap<String, Integer>();

    /*
    Funció on afegim una nova edat a la tupla si no existia o incrementem una aparició altrament.
     */
    public void afegeix(String edat) {

        if(edat.equals("") || edat.equals("No consta")) edat = "Sense especificar";

        if(this.edades.containsKey(edat))
        {
            int valor = this.edades.get(edat) + 1;
            this.edades.put(edat, valor);
        }
        else{
            this.edades.put(edat, 1);
        }
    }

    /*
    Sobrescribim la funció toString per a que ens reorni el valor en String de la classe.
     */
    @Override
    public String toString() {

        String result = "";

        for (Map.Entry<String, Integer> entry : this.edades.entrySet()) {
            result += "Denúncies amb edat " + entry.getKey() + " = " + entry.getValue() + "\n";
        }

        return result;
    }
}
