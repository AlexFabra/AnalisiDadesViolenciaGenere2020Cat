import java.util.HashMap;
import java.util.Map;

//a ViolenciaDomestica s'analitza si el presumpte agressor i la persona denunciant convivien
public class ViolenciaDomestica {
    //Guardem en una tupla un string que representarà si ha hagut violencia doméstica
    //i el número de casos que s'han donat, tant si ha hagut com si no.

    private Map<String, Integer> vDom = new HashMap<String, Integer>();

    /**
     *
     * @param conviu
     */
    public void afegeix(String conviu) {

        if(conviu.equals("") || conviu.equals("No consta")) conviu = "Sense especificar";

        if(this.vDom.containsKey(conviu))
        {
            int valor = this.vDom.get(conviu) + 1;
            this.vDom.put(conviu, valor);
        }
        else{
            this.vDom.put(conviu, 1);
        }
    }

    /*
    Sobrescribim la funció toString per a que ens reorni el valor en String de la classe.
     */
    @Override
    public String toString() {

        String result = "";
        result += "Denúncies de violencia domèstica?\n";
        for (Map.Entry<String, Integer> entry : this.vDom.entrySet()) {
            result += entry.getKey() + " = " + entry.getValue() + "\n";
        }

        return result;
    }
}

