import java.util.HashMap;
import java.util.Map;

//La classe denunciant ajuda a classificar quin rol té en la vida de la víctima qui truca i quantes vegades surt aquest rol:
public class Denunciant {

    private Map<String, Integer> trucants = new HashMap<String, Integer>();

    public void afegeix(String trucant){
        //si el paràmetre introduit és un String vuit, li canviem el valor a 'Anònim':
        if(trucant.equals("")){
            trucant = "Anònim";
        } 
        //si el map conté la clau trucant, actualitzarem el seu valor:
        if(this.trucants.containsKey(trucant))
        {
            int valor = this.trucants.get(trucant) + 1;
            this.trucants.put(trucant, valor);
        }
        //si no conté la clau, la afegim i iniciem el valor en 1:
        else
        {
            this.trucants.put(trucant, 1);
        }
    }

    /*
    Sobrescribim la funció toString per a que ens reorni el valor en String de la classe.
     */
    @Override
    public String toString() {

        String result = "";
        //recorrem el hashmap retornant les claus i el nombre de repeticions:
        for (Map.Entry<String, Integer> entry : this.trucants.entrySet()) {
            result += entry.getKey() + " = " + entry.getValue() + "\n";
        }

        return result;
    }
}

